.. _python-support:

Python Support
==============

Pillow supports these Python versions.

.. csv-table:: Newer versions
   :file: newer-versions.csv
   :header-rows: 1

.. csv-table:: Older versions
   :file: older-versions.csv
   :header-rows: 1
